#include<stdio.h>
int main()
{
	int i,n;
	printf("enter the value of n\n");
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		printf("%d\n",i);
	}
	return 0;
}
