#include<stdio.h>
int main()
{
	int n,i,j,count=0;
	printf("enter the limit");
	scanf("%d",&n);
	for(j=1;j<=n;j++)
	{
		for(i=0;i<=j;i++)
		{
			if(j%i==0)
			{
				count++;
			}
		}
    }
		if(count==2)
		{
			printf("%d",j);
		}
	return 0;
}
