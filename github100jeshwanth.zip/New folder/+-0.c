#include<stdio.h>
int main()
{
	int x;
	printf("enter the value of a\n");
	scanf("%d",&x);
	if(x>0)
	{
		printf("x is positive");
	}
	else if(x==0)
	{
		printf("x is zero");
	}
	else
	{
		printf("x is negative");
	}
	return 0;
}
