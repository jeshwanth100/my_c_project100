#include<stdio.h>
int main()
{
	int a,b,sum,avg;
	printf("Enter the values of a and b\n");
	scanf("%d%d",&a,&b);
	sum=a+b;
	avg=sum/2;
	printf("avg=%d",avg);
	return 0;
}
