#include<stdio.h>
int main()
{
	int l,b,area;
	printf("Enter the values of l and b\n");
	scanf("%d%d",&l,&b);
	area=l*b;
	printf("area=%d",area);
	return 0;
}
