#include<stdio.h>
int main()
{
	int a;
	printf("enetr the value of a\n");
	scanf("%d",&a);
	if(a%2==0)
	{
		printf("a is even");
	}
	else
	{
		printf("a is odd");
	}
	return 0;
}
