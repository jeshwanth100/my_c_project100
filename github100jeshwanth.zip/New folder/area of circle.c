#include<stdio.h>
int main()
{
	int r,area;
	float PI;
	PI=3.14;
	printf("enetr the value of r\n");
	scanf("%d",&r);
	area=PI*r*r;
	printf("area of circle:%d",area);
	return 0;
}
